﻿var gulp = require('gulp');
var minify = require('gulp-minify');

gulp.task('default', function () {

    return gulp.src('Src/**')
        .pipe(minify())
        .pipe(gulp.dest('./Target'));
})