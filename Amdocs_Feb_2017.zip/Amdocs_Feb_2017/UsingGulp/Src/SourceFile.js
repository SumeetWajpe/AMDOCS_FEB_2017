﻿var stringVar = 'Hello !';
var numVar = 100;
var boolVar = false;

function Add(veryLongX,veryLongY) {
    return veryLongX + veryLongY;
}